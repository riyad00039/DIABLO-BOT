import fetch from "node-fetch";

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇📚 هل تظن أنني أقرأ العقول؟ اكتب شيئًا بعد الأمر ↞*
*⎆┇مثال: .دليل افضل انمي ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);
  }

  await m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇... انتظر لحظة، سأبحث لك عن أفضل الإجابات ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);

  try {
    let result = await CleanDx(text);
    await m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇📚 دليل الترفيه ↞*
${result}
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);
  } catch (e) {
    await m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇📚 أعتذر، لم أتمكن من الحصول على المعلومات ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);
  }
};

handler.help = ["دليل"];
handler.tags = ["ai"];
handler.command = /^(دليل)$/i;

export default handler;

async function CleanDx(your_qus) {
  let Baseurl = "https://alakreb.vercel.app/api/ai/gpt?q=";
  
  // توجيه الـ API ليكون دليل شامل لكل شيء ترفيهي
  let prompt = `أنت دليل شامل لكل شيء يتعلق بالترفيه. يجب أن تكون قادرًا على تقديم معلومات عن الأنمي، المسلسلات، الكرتون، الأفلام، المانهوا وكل أنواع الترفيه. سؤالي هو: ${your_qus}`;

  let response = await fetch(Baseurl + encodeURIComponent(prompt));
  let data = await response.json();
  return data.message;
}