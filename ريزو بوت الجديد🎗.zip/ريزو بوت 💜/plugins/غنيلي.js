//════════════════════════════//
//     🎧 AI MUSIC GENERATOR 🎶
//        Developed by TYSON
//════════════════════════════//

import fetch from "node-fetch";

const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    //───────────────────────────────//
    // 🟡 التحقق من الإدخال
    //───────────────────────────────//
    if (!text)
      return m.reply(
        `*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*\n` +
        `*⎆┇الـحـالـة🚫↞:* خـطـأ فـي الإدخـال ❌\n` +
        `*⎆┇الـرسـالـة📩↞:* الرجاء كتابة اسم الأغنية أو الجملة 🎵\n` +
        `*⎆┇مـثـال🎧↞:* \`${usedPrefix + command} sad cat\`\n` +
        `*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`
      );

    //───────────────────────────────//
    // 🕐 رسالة الانتظار
    //───────────────────────────────//
    const waitMsg = await conn.sendMessage(
      m.chat,
      {
        text:
          `*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*\n` +
          `*⎆┇الـحـالـة🎶↞:* جـاري إِعـداد أغـنـيـتـك ... 🎧\n` +
          `*⎆┇الـرجـاء⌛↞:* انـتـظـر قـلـيـلًا، يـتـم تـولـيـد الـكـلـمـات والـلـحـن 🎵\n` +
          `*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`,
      },
      { quoted: m }
    );

    //───────────────────────────────//
    // 🔵 استدعاء API
    //───────────────────────────────//
    const prompt = encodeURIComponent(text);
    const api = `https://api-tyson-md.vercel.app/api/ai/suno?prompt=${prompt}`;
    let res = await fetch(api);
    let data = await res.json();

    //───────────────────────────────//
    // 🔴 فشل توليد الأغنية
    //───────────────────────────────//
    if (!data?.status || !data?.song?.url) {
      return conn.sendMessage(
        m.chat,
        {
          text:
            `*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*\n` +
            `*⎆┇الـحـالـة❌↞:* فـشـل تـولـيـد الأغـنـيـة\n` +
            `*⎆┇الـرسـالـة📩↞:* حدث خـطـأ أثناء الإنشاء، حاول لاحقًا 🔁\n` +
            `*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`,
        },
        { quoted: m }
      );
    }

    //───────────────────────────────//
    // 🟢 بيانات الأغنية ونتيجتها
    //───────────────────────────────//
    const { name, url, thumbnail } = data.song;

    // 🎵 إرسال بطاقة النتيجة النهائية
    await conn.sendMessage(
      m.chat,
      {
        image: { url: thumbnail },
        caption:
          `*╮────🎶ريـــزو ميوزيك🎶───⟢ـ*\n` +
          `*⎆┇الـنـتـيـجـة🎶↞:* تـم تـولـيـد أغـنـيـتـك بـنـجـاح 🎧\n` +
          `*⎆┇الاسـم💿↞:* *"${name}"*\n` +
          `*⎆┇الـرابـط🔗↞:* (${url})\n` +
          `*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*\n\n` +
          `> 🎧 *تم الإنشاء بواسطة* ᖇYᘔO ᗷOT ⚡`,
      },
      { quoted: waitMsg }
    );

    // 🎧 إرسال الصوت نفسه
    await conn.sendMessage(
      m.chat,
      {
        audio: { url },
        mimetype: "audio/mpeg",
        fileName: `${name}.mp3`,
        ptt: false,
      },
      { quoted: m }
    );
  } catch (err) {
    console.error(err);
    await conn.sendMessage(
      m.chat,
      {
        text:
          `*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*\n` +
          `*⎆┇الـحـالـة⚠️↞:* خـطـأ غـيـر مـتـوقـع 🧩\n` +
          `*⎆┇الـرسـالـة📩↞:* جرب بعد دقائق قليلة 🔁\n` +
          `*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`,
      },
      { quoted: m }
    );
  }
};

handler.command = ["غنيلي", "اغنيتي", "aiغني"];
handler.help = ["غنيلي"];
handler.tags = ["ai", "music"];

export default handler;