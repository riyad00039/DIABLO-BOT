/* 💎 تم التنسيق بواسطة 💜 ᖇYᘔO ᗷOT 💎 */
import pkg from '@whiskeysockets/baileys'
const { prepareWAMessageMedia } = pkg

const handler = async (m, { conn }) => {
  try {
    let name = await conn.getName(m.sender)
    let user = global.db.data.users[m.sender]
    let role = user?.role || 'ذكاء اصطناعي 🤖'

    await conn.sendMessage(m.chat, { react: { text: '🌠', key: m.key } })

    const imageUrl = 'https://files.catbox.moe/8ehq4f.jpg'
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer })

    let caption = `
╭━━〔😎 قـسـم الوجوهات 💜〕━━⬣
┃ ➟ *مرحباً بك يا* 『${name}』
┃ ➟ *🏮 الرتبة:* ${role}
┃ ➟ *😎 قسم الوجوهات جاهز لخدمتك*
╰━━━━━━━━━━━━⬣

╭━━〔😎 أوامـر الوجوهات 💜〕━━⬣
┃ ➟ ❤️ *『شعار_قلب』*
┃ ➟ 🎄 *『شعار_الكريسماس』*
┃ ➟ 💑 *『شعار_زوجين』*
┃ ➟ ⚡ *『شعار_جلتش』*
┃ ➟ 😢 *『شعار_حزين』*
┃ ➟ 🎮 *『شعار_جيمنج』*
┃ ➟ 👤 *『شعار_وحيد』*
┃ ➟ 🐲 *『شعار_دراغون_بول』*
┃ ➟ 🔮 *『شعار_نيون』*
┃ ➟ 🐱 *『شعار_قطتي』*
┃ ➟ 👧🎮 *『شعار_فتاة_جيمر』*
┃ ➟ 🍥 *『شعار_ناروتو』*
┃ ➟ 🤖 *『شعار_مستقبلي』*
┃ ➟ ☁️ *『شعار_سحاب』*
┃ ➟ 👼 *『شعار_ملاك』*
┃ ➟ 🌌 *『شعار_سماء』*
┃ ➟ 🎨 *『شعار_جرافيتي_ثلاثي』*
┃ ➟ 🧪 *『شعار_ماتريكس』*
┃ ➟ 👹 *『شعار_رعب』*
┃ ➟ 🪽 *『شعار_أجنحة』*
┃ ➟ 🪖 *『شعار_جيش』*
┃ ➟ 🔫 *『شعار_ببجي』*
┃ ➟ 👧🔫 *『شعار_ببجي_بناتي』*
┃ ➟ 😂 *『شعار_لول』*
┃ ➟ 👽 *『شعار_امونج_اس』*
┃ ➟ 📹 *『فيديو_شعار_ببجي』*
┃ ➟ 🐅🎞️ *『فيديو_شعار_نمر』*
┃ ➟ 🎬 *『فيديو_مقدمة』*
┃ ➟ 🕹️🎞️ *『فيديو_شعار_جيمنج』*
┃ ➟ ⚔️ *『شعار_محارب』*
┃ ➟ 🖼️ *『غلاف_لاعب』*
┃ ➟ 🔥🖼️ *『غلاف_فري_فاير』*
┃ ➟ 🔫🖼️ *『غلاف_ببجي』*
┃ ➟ 🎯🖼️ *『غلاف_كونتر』*
╰━━━━━━━━━━━━⬣

> 😎 *قسم الوجوهات بإدارة 💜 ᖇYᘔO ᗷOT 💜*
`.trim()

    let msg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: caption },
            footer: { text: '💜 ⦓ ᖇYᘔO ᗷOT ⦔ 💜' },
            header: { hasMediaAttachment: true, ...media },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "🎗 القــــــناه",
                    url: "https://whatsapp.com/channel/0029VbBLsfKLY6d1J52Uvv3U"
                  })
                }
              ]
            }
          }
        }
      }
    }

    await conn.relayMessage(m.chat, msg, {})

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m })
  }
}

handler.command = ['ق14']
handler.tags = ['logos']
handler.help = ['ق14']

export default handler