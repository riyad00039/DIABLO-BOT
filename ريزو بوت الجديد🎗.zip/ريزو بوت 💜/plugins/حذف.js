const handler = async (m, { conn, isAdmin, isOwner }) => {
  if (!m.quoted) {
    return conn.reply(
      m.chat,
      `*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇⚠️ من فضلك قم بالرد على الرسالة التي تريد حذفها ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`,
      m
    );
  }

  if (!(isAdmin || isOwner))
    return m.reply(
      `*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇⚠️ هذا الأمر مخصص للمشرفين فقط ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`
    );

  const key = {
    remoteJid: m.chat,
    fromMe: false,
    id: m.quoted.id,
    participant: m.quoted.sender,
  };

  try {
    await conn.sendMessage(m.chat, { delete: key });

    // رد تأكيد فقط بعد نجاح الحذف
    return m.reply(
      `*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇🗑️ تم حذف الرسالة بنجاح ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`
    );
  } catch (err) {
    console.error('فشل الحذف:', err);

    // إذا الخطأ فعلاً من صلاحيات المشرف
    if (String(err).includes('not-authorized') || String(err).includes('admin')) {
      return conn.reply(
        m.chat,
        `*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇❌ لم أتمكن من حذف الرسالة، تأكد أني مشرف ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`
      );
    }

    // أي خطأ آخر
    return conn.reply(
      m.chat,
      `*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇⚠️ حدث خطأ غير متوقع أثناء الحذف ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`
    );
  }
};

handler.help = ['حذف'];
handler.tags = ['group'];
handler.command = ['حذف', 'مسح', 'delete', 'del'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;