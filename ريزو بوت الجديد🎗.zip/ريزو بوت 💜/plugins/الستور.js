import fetch from "node-fetch";

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇🔪 هل تظن أنني أقرأ العقول؟ اكتب شيئًا بعد الأمر ↞*
*⎆┇مثال: .استور افضل انمي ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);

  await m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇... هذا الوقت الذي تضيع فيه، فقط لأسألك؟ انتظر لحظة ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);

  try {
    let result = await CleanDx(text);
    await m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇💀 رد الاستور ↞*
${result}
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);
  } catch (e) {
    await m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇هل تظن أنني أهتم؟ حتى الـ AI لا يتوانى عن تجاهلك ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);
  }
};

handler.help = ["dx"];
handler.tags = ["ai"];
handler.command = /^(الستور)$/i;

export default handler;

async function CleanDx(your_qus) {
  let Baseurl = "https://alakreb.vercel.app/api/ai/gpt?q=";
  
  // توجيه للـ API بأسلوب الاستور من "هازبين هوتيل"
  let prompt = `تحدث كـ الاستور من "هازبين هوتيل". استخدم أسلوبه الخاص في الرد، قسوة، سخرية، وذكاء لاذع. سؤالي هو: ${your_qus}`;

  let response = await fetch(Baseurl + encodeURIComponent(prompt));
  let data = await response.json();
  return data.message;
}