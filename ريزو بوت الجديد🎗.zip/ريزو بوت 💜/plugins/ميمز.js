const dir = [
  // الصور الجديدة والقديمة
  'https://telegra.ph/file/25a14cd4fff811de1475f.jpg',
  'https://telegra.ph/file/645de7e8ce68ade591bb2.jpg',
  'https://telegra.ph/file/4b540ca77c8b2a1d1ec57.jpg',
  'https://telegra.ph/file/53a5a6a5b2d71c6d3c163.jpg',
  'https://telegra.ph/file/48571aa7be63a3de59ff2.jpg',
  'https://telegra.ph/file/553bca98fe9dec4270ad7.jpg',
  'https://telegra.ph/file/87a7bda3cfde01d2348ed.jpg',
  'https://telegra.ph/file/7c24e7540548c2d74d424.jpg',
  'https://telegra.ph/file/60eeedd13a6bb5be507b5.jpg',
  'https://telegra.ph/file/328d7865de1bd1971a557.jpg',
  'https://telegra.ph/file/e4b0461725fc22520eda9.jpg',
  'https://telegra.ph/file/9bb6046502993d6ce6518.jpg',
  'https://telegra.ph/file/8890c73047805cf78c00a.jpg',
  'https://telegra.ph/file/dc81295351494c2a1c472.jpg',
  'https://telegra.ph/file/4232a1c385ff9da68aef6.jpg',
  'https://telegra.ph/file/ea550661d8ab4b84c6296.jpg',
  'https://telegra.ph/file/8b2190dc849e24972152c.jpg',
  'https://telegra.ph/file/f207b57a1f51412a203e7.jpg',
  'https://telegra.ph/file/cf2fccd900ff2d0d131a1.jpg',
  'https://telegra.ph/file/940e82466ed78e975a745.jpg',
  'https://telegra.ph/file/b0c749d5e802332dcc11f.jpg',
  'https://telegra.ph/file/769d89ef7f7336bd05a80.jpg',
  'https://telegra.ph/file/f9138226511b3a30e958b.jpg',
  'https://telegra.ph/file/8281fdf957ebca93aec0f.jpg',
  'https://telegra.ph/file/3c6dd91466c9ed89d2bf7.jpg',
  'https://telegra.ph/file/8bcad0c566c5f51ffe5bb.jpg',
  'https://telegra.ph/file/4ac11fe77b659d5168b1e.jpg',
  'https://telegra.ph/file/c3fcd3e486c6a3bee6f4f.jpg',
  'https://telegra.ph/file/31de70933034c724b74f1.jpg',
  'https://telegra.ph/file/2d249ca2b62c18af6baa3.jpg',
  'https://telegra.ph/file/ef8ebed7d971ce6de5ee9.jpg',
  'https://telegra.ph/file/777fb5cb0f6be330f9b8a.jpg',
  'https://telegra.ph/file/20aef78978a92b8b0444b.jpg',
  'https://telegra.ph/file/20bc0e05daf3272ea89b9.jpg',
  'https://telegra.ph/file/a915d3752bac387b81adf.jpg',
  'https://telegra.ph/file/c20048814324dd1a1bb77.jpg',
  'https://telegra.ph/file/3b945a8a14851ece29de7.jpg',
  'https://telegra.ph/file/abf7e03745ca2d298a9c1.jpg',
  'https://telegra.ph/file/13e4a77349596c5ab8a79.jpg',
  'https://telegra.ph/file/32bc65b3c0baa1eb6c284.jpg',
  'https://telegra.ph/file/1c231e0675b7f6edd579a.jpg',
  'https://telegra.ph/file/c564473a41ab8405dc3b9.jpg',
  'https://telegra.ph/file/aa8bd2a777b01d0b24f4d.jpg',
  'https://telegra.ph/file/59c075e64bdd0e17b659f.jpg',
  'https://telegra.ph/file/f7c59f1787705d36043ca.jpg',
  'https://telegra.ph/file/58081f8a94dbd1d1caf40.jpg',
  'https://telegra.ph/file/e1539e82d5bc96bc9f15e.jpg',
  'https://telegra.ph/file/36efa93ee22207c36ad2d.jpg',
  'https://telegra.ph/file/6df3e879dd9c2e908859f.jpg',
  'https://telegra.ph/file/65dc15eb996d69742fcb9.jpg',
  'https://telegra.ph/file/986928ae97ba48c5f54be.jpg',
  'https://telegra.ph/file/92379479bbe99f312f13f.jpg',
  'https://telegra.ph/file/c46fda1ffbbaa3c406a29.jpg',
  'https://telegra.ph/file/0d32e11e4a0dae13dac3d.jpg',
  'https://telegra.ph/file/13a65df594224f0c46561.jpg',
  'https://telegra.ph/file/17d2fd7d6e0fbfe0d74dd.jpg',
  'https://telegra.ph/file/98acc5caa337ba06407b5.jpg',
  'https://telegra.ph/file/102561f89b0967f27ce63.jpg',
  'https://telegra.ph/file/e4f06eb175994ef6ebd41.jpg',
  'https://telegra.ph/file/bf3a36c8f30e56dcbbfa5.jpg',
  'https://telegra.ph/file/3a5b3ea59347b2f8fb805.jpg',
  'https://telegra.ph/file/60262d7d56b4352993e88.jpg',
  'https://telegra.ph/file/2d692d315587805dde1a9.jpg',
  'https://telegra.ph/file/e51a3c070b031ccefb801.jpg',
  'https://telegra.ph/file/a0a8e70592a5b2ccd2987.jpg',
  'https://telegra.ph/file/5e1fc88c8803a0fc31523.jpg',
  'https://telegra.ph/file/1f54bdd48b568aa05d593.jpg',
  'https://telegra.ph/file/62ac12702441491e0c73b.jpg',
  'https://telegra.ph/file/fa537428bb58b297e3ed3.jpg',
  'https://telegra.ph/file/3155c1dc08fa26970d858.jpg',
  'https://telegra.ph/file/e926a13e06728028d860d.jpg',
  'https://telegra.ph/file/71e8a40317d9dd6dce50.jpg',
  'https://telegra.ph/file/1c9f11a44ac8ed88e073e.jpg',
  'https://telegra.ph/file/271155de61db260ef09ba.jpg',
  'https://telegra.ph/file/d898b26a10495e8c6792b.jpg',
  'https://telegra.ph/file/f6b71e125dd4971253c39.jpg',
  'https://telegra.ph/file/73e9f8a1692c470e63d04.jpg',
  'https://telegra.ph/file/6c72d75cbb596fd757aba.jpg',
  'https://telegra.ph/file/ede1c654d4c218c0b263b.jpg',
  'https://telegra.ph/file/078671b7aee6dd8c4ae09.jpg',
  'https://telegra.ph/file/04f6a1c2c271e3d0d9b08.jpg',
  'https://telegra.ph/file/e1f3bc35cb2b201ec12e4.jpg',
  'https://telegra.ph/file/0d6fb4189e171d90505f8.jpg',
  'https://telegra.ph/file/efa364c3e60769ba75743.jpg',
  'https://telegra.ph/file/65bf5dbc42b5c43fc5d2f.jpg',
  'https://telegra.ph/file/03fd2e33eef17aa189e5a.jpg',
  'https://telegra.ph/file/855054f8f233540b8bdc7.jpg'
];

let handler = async (m, { conn }) => {
  const randomImage = dir[Math.floor(Math.random() * dir.length)];

  // إرسال تفاعل
  await conn.sendMessage(m.chat, {
    react: {
      text: '🤡', // يمكنك تغييره لأي إيموجي
      key: m.key
    }
  });

  // إرسال الصورة مع تعليق البوت
  await conn.sendMessage(m.chat, {
    image: { url: randomImage },
    caption: '✨ ᖇYᘔO ᗷOT',
  }, { quoted: m });
};

handler.help = ['ميمز-انمي'];
handler.tags = ['game'];
handler.command = /^(ميمز)$/i;
handler.limit = true;

export default handler;