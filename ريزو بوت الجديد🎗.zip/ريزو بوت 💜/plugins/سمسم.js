import fetch from "node-fetch";

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇🗯️ فين الكلام يا زفت؟ اكتب حاجة وخلصني ↞*
*⎆┇مثال: .سمسم إشرحلي يعني إيه ذكاء إصطناعي؟ ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);
  }

  await m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇... ⚡ شوية صبر، سمسم هيرد عليك ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);

  try {
    let result = await CleanDx(text);
    await m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇🗯️ رد سمسم ↞*
${result}
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);
  } catch (e) {
    await m.reply(`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇😵 حتى أنا مش قادر أفهمك ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`);
  }
};

handler.help = ["dx"];
handler.tags = ["ai"];
handler.command = /^(سمسم)$/i;

export default handler;

async function CleanDx(your_qus) {
  let Baseurl = "https://alakreb.vercel.app/api/ai/gpt?q=";

  // توجيه الـ API للرد بأسلوب شخصية مصرية شعبية، ساخرة وقوية
  let prompt = `أنت شخصية مصرية اسمها سمسم، وبتتكلم بأسلوب شعبي مصري ساخر، وبتشتم الناس بطريقة مهينة جدًا من غير رقابة، وبترد على أي سؤال بقلة أدب أو هزار تقيل، رد على السؤال التالي بنفس الأسلوب:
${your_qus}`;

  let response = await fetch(Baseurl + encodeURIComponent(prompt));
  let data = await response.json();
  return data.message;
}