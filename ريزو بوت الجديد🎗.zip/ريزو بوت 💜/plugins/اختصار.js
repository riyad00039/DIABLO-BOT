import fetch from "node-fetch"

let handler = async (m, { text }) => {
  if (!text) return m.reply(
`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇ ⚠️ اكتب الرابط اللي عايز تختصره 🌐 ↞*
*⎆┇ مـثـال: .اختصار https://example.com ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`
  )

  try {
    let api = `https://tinyurl.com/api-create.php?url=${encodeURIComponent(text)}`
    let res = await fetch(api)
    let shortUrl = await res.text()

    m.reply(
`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇ تم اختصار الرابط بنجاح ✅ ↞*
*⎆┇ ${shortUrl} ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`
    )
  } catch (e) {
    m.reply(
`*╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*
*⎆┇ ❌ حدث خطأ أثناء اختصار الرابط ↞*
*⎆┇ حاول مرة أخرى لاحقًا ↞*
*╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈⟐*`
    )
  }
}

handler.help = ['اختصار <link>']
handler.tags = ['tools']
handler.command = /^(اختصار)$/i

export default handler